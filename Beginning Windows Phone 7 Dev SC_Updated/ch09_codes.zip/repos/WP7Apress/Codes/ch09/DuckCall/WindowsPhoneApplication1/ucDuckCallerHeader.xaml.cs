﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WindowsPhoneApplication1
{
	public partial class ucDuckCallerHeader : UserControl
	{
		public ucDuckCallerHeader()
		{
			// Required to initialize variables
			InitializeComponent();
		}
	}
}