﻿using System.Windows;
using Microsoft.Phone.Controls;

namespace RobotSoundDemo
{
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            MoveRobot.Begin();
            
            robotSound.Stop();
            robotSound.Source = new System.Uri("sound26.wma", System.UriKind.Relative);

            System.Threading.Thread.Sleep(50);
            robotSound.Play();
        }
    }
}
